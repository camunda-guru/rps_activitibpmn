package com.cts.springbootactivactiviti.SpringBootActivitiDemo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonRepository extends JpaRepository<Person, Long> {
	Person findByName(String name);
}
