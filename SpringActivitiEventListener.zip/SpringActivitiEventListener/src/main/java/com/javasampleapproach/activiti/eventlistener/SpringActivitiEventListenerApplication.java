package com.javasampleapproach.activiti.eventlistener;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.*")
public class SpringActivitiEventListenerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringActivitiEventListenerApplication.class, args);
	}
}
